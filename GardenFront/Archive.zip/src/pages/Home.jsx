
function HomePage() {

    return null
}

export default HomePage;