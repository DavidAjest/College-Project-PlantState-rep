
# React frontend with tailwindcss

# How  to use
## Setup
```bash
npm install
```

## Development

```bash
npm run dev
```

## Build

```bash
npm run build
```
